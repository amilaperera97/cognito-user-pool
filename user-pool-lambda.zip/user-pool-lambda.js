exports.handler = async (event) => {
    const AWS = require('aws-sdk');
    const cognito = new AWS.CognitoIdentityServiceProvider();
    
    const method = event.httpMethod;
    const body = JSON.parse(event.body);

    if (method === 'POST' && event.path === '/register') {
        // Register User
        const params = {
            UserPoolId: process.env.USER_POOL_ID,
            Username: body.email,
            TemporaryPassword: body.password,
            UserAttributes: [
                {
                    Name: 'email',
                    Value: body.email,
                },
            ],
        };

        try {
            await cognito.adminCreateUser(params).promise();
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'User created successfully' }),
            };
        } catch (error) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: error.message }),
            };
        }
    }

    if (method === 'POST' && event.path === '/login') {
        // Login User
        const params = {
            AuthFlow: 'USER_PASSWORD_AUTH',
            ClientId: process.env.CLIENT_ID,
            AuthParameters: {
                USERNAME: body.email,
                PASSWORD: body.password,
            },
        };

        try {
            const authResponse = await cognito.initiateAuth(params).promise();
            return {
                statusCode: 200,
                body: JSON.stringify({ message: 'Login successful', token: authResponse.AuthenticationResult.IdToken }),
            };
        } catch (error) {
            return {
                statusCode: 400,
                body: JSON.stringify({ message: error.message }),
            };
        }
    }
};
